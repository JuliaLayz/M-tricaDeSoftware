public class ExceptionCalculadora extends Exception {

    public ExceptionCalculadora(String message) {
        super(message);
    }

    public static ExceptionCalculadora erroAoDividirPorZero() {
        return new ExceptionCalculadora("Não posso dividir por zero");
    }

    public static ExceptionCalculadora erroAoCalcularRaizNegativa() {
        return new ExceptionCalculadora("Não é possível calcular a raiz de um número negativo");
    }

    public static ExceptionCalculadora erroAoCalcularLogaritmoNegativo() {
        return new ExceptionCalculadora("Não é possível calcular o logaritmo de um número negativo");
    }
}
